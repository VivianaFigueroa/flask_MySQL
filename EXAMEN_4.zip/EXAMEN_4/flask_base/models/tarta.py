import os

from flask_base.config.mysqlconnection import connectToMySQL
from flask_base.models.modelo_base import ModeloBase

class Tarta(ModeloBase):

    modelo = 'tarta'
    campos = ['nombre','relleno','corteza','usuarios_id']

    def __init__(self, data):
        self.id = data['id']
        self.nombre = data['nombre']
        self.relleno = data['relleno']
        self.corteza = data['corteza']
        self.usuarios_id = data['usuarios_id']
        self.created_at = data['created_at']
        self.updated_at = data['updated_at']
