from flask import redirect, render_template, request, session
from flask_base import app
from flask import flash
from flask_base.models.tarta import Tarta

@app.route('/tablero')
def tablero():
    return render_template('tableros/tablero.html', all_tartas = Tarta.get_all_with_user())

@app.route('/tartas')
def tarta():
    return render_template('tartas/tartadervy.html')

@app.route('/procesar_tarta', methods=(['POST']))
def nueva_tarta():

    print(request.form)
    if not Tarta.validar(request.form):
        return redirect('/tarta/nueva')

    nueva_tarta = {
        'nombre' : request.form['nombre'],
        'relleno' : request.form['relleno'],
        'corteza' : request.form['corteza']
    }
    tarta = Tarta.save(nueva_tarta)
    if tarta == False:
        flash('Algo salió mal con la creación', 'error')
        return redirect('/tablero')
    print (tarta)
    return redirect('/tarta')

@app.route('/tarta/editar/<int:id>')
def proceso_tarta(id):
    if 'usuario_id' not in session:
        return redirect('/login')
    tarta = Tarta.get_by_id(id)
    print(tarta)
    return render_template('tartas/tableroTarta.html')


app.route('/editar')
def editar():
    return render_template('editar/editar.html')