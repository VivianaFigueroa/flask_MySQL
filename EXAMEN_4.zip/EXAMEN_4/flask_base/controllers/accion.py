from flask import render_template
from flask_base import app
from flask import render_template

@app.route('/acciones')
def acciones():
    
    return render_template('acciones/acciones.html')
