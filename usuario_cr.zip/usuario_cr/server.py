from flask import Flask, render_template, request, redirect
app = Flask (__name__)

from user import User

@app.route('/users')
def all_users():
    all_users = User.get_all()
    print(all_users)
    return render_template('index.html', all_users=all_users)

@app.route('/process', methods=["POST"])
def process_user():
    data = {
        "first_name": request.form["first_name"],
        "last_name" : request.form["last_name"],
        "email" : request.form["email"]
    }
    User.save(data)

    return redirect('/users')

@app.route('/users/new')
def add_new_user():
    return render_template('addNewUser.html')

if __name__ == "__main__":
    app.run(debug=True)