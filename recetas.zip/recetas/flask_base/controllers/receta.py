from flask import flash, redirect, render_template, request, session
from flask_base import app
from flask_base.models.receta import Receta


@app.route('/recetas')
def receta():
    if 'usuario_id' not in session:
        return redirect('/login')
    return render_template ('recetas/recetas.html', all_recetas = Receta.get_all_with_user())

@app.route('/recetas/<int:id>')
def view_receta(id):
    if 'usuario_id' not in session:
        return redirect('/login')
    receta = Receta.get_by_id_with_user(id)[0]
    receta.fecha_creacion = receta.fecha_creacion.strftime("%Y-%m-%d")    
    return render_template ('recetas/verReceta.html', receta = receta)

@app.route('/recetas/eliminar/<int:id>')
def delete_receta(id):
    if 'usuario_id' not in session:
        return redirect('/login')
    receta=Receta.get_by_id_with_user(id)[0]
    if session ['usuario_id'] == receta.usuario_id:
        receta = Receta.delete(id)
        print(receta)
        return redirect ('/recetas')

    return redirect('/recetas')

@app.route('/recetas/nueva')
def new_receta():
    if 'usuario_id' not in session:
        return redirect('/login')
    return render_template ('/recetas/crearReceta.html')


@app.route('/procesar_receta', methods=['POST'])
def receta_procesar():

    print(request.form)
    if not Receta.validar(request.form):
        return redirect ('/recetas/nueva')

    nueva_receta= {
        'titulo' : request.form['titulo'],
        'descripcion' : request.form['descripcion'],
        'instrucciones' : request.form['instrucciones'],
        'fecha_creacion' : request.form['fecha_creacion'],
        'bajo_30'  : request.form['bajo_30'],
        'usuarios_id' : session ['usuario_id']
    }
    receta = Receta.save(nueva_receta)
    if receta == False:
            flash('No se ha podido procesar nueva receta', 'error')
            return redirect ('/recetas/nueva')
    print(receta)
    return redirect('/recetas')

@app.route('/recetas/editar/<int:id>')
def editar_receta(id):
    if 'usuario_id' not in session:
        return redirect('/login')
    receta = Receta.get_by_id_with_user(id) [0]
    if session ['usuario_id'] == receta.usuario_id:
        receta.fecha_creacion = receta.fecha_creacion.strftime("%Y-%m-%d")
        return render_template ('recetas/editarReceta.html', receta=receta)
    
    return redirect(f'/recetas/{id}') 

@app.route('/procesar/editar/receta/<int:id>', methods = ['POST'])
def procesar_editar_receta(id):
        print(request.form)

        updated_receta= {
            'id' : id,
            'titulo' : request.form['titulo'],
            'descripcion' : request.form['descripcion'],
            'instrucciones' : request.form['instrucciones'],
            'fecha_creacion' : request.form['fecha_creacion'],
            'bajo_30'  : request.form['bajo_30'],
        }
        updated  = Receta.update(updated_receta)
        return redirect ('/recetas')