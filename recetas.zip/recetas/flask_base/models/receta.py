import os 

from flask_base.config.mysqlconnection import connectToMySQL
from flask_base.models.modelo_base import ModeloBase
from flask import flash

class Receta(ModeloBase):

    modelo = 'receta'
    campos = ['titulo', 'descripcion', 'instrucciones', 'fecha_creacion', 'bajo_30', 'usuarios_id']

    def __init__(self, data):
        self.id = data['id']
        self.titulo = data['titulo']
        self.descripcion = data['descripcion']
        self.instrucciones = data['instrucciones']
        self.fecha_creacion = data['fecha_creacion']
        self.bajo_30 = data['bajo_30']
        self.usuario_id = data['usuarios_id']
        self.usuario_nombre = data ['nombre']
        self.created_at = data['created_at']
        self.updated_at = data['updated_at']

    @classmethod
    def get_all_with_user(cls):
            query = f"SELECT * FROM {cls.modelo} JOIN usuarios ON usuarios.id = {cls.modelo}.usuarios_id;"
            results= connectToMySQL(os.environ.get("BASEDATOS_NOMBRE")).query_db(query)
            all_data = []
            for data in results:
                all_data.append(cls(data))
            return all_data

    @classmethod
    def get_by_id_with_user(cls, id):
            query = f"SELECT * FROM {cls.modelo} JOIN usuarios ON usuarios.id = {cls.modelo}.usuarios_id WHERE receta.id = %(id)s;"
            data = {'id' : id}
            results= connectToMySQL(os.environ.get("BASEDATOS_NOMBRE")).query_db(query, data)
            all_data = []
            for data in results:
                all_data.append(cls(data))
            return all_data

    @classmethod
    def update(cls, data):
        query = """UPDATE receta
                                    SET titulo = %(titulo)s,
                                    descripcion = %(descripcion)s
                                    instrucciones = %(instrucciones)s
                                    fecha_creacion = %(fecha_creacion)s
                                    bajo_30 = %(bajo_30)s
                                    updated_at = NOW()
                            WHERE id = %(id)s"""
        resultado= connectToMySQL(os.environ.get("BASEDATOS_NOMBRE")).query_db(query)
        print("RESULTADO: ", resultado)
        return resultado

    @staticmethod
    def validar_largo(data, campo, largo):
        is_valid = True
        if len(data[campo]) <= largo:
            flash(f'El largo del {campo} no puede ser menor o igual {largo}', 'error')
            is_valid = False
        return is_valid

    @classmethod
    def validar(cls, data):

        is_valid = True
        is_valid = cls.validar_largo(data, 'titulo', 3)
        if not is_valid:
            is_valid = cls.validar_largo(data, 'descripcion', 3)
            is_valid = False
        if not is_valid:
            is_valid = cls.validar_largo(data, 'instrucciones', 3)
            is_valid = False
        if not is_valid:
            is_valid = cls.validar_largo(data, 'fecha_creacion', 9)
            is_valid = False

        return is_valid