# Para tener en cuenta.

```
APP_SECRET_KEY=sesion
BASEDATOS_HOST=localhost
BASEDATOS_USER=root
BASEDATOS_PASSWORD=root
BASEDATOS_NOMBRE=db_recetas
NOMBRE_SISTEMA= Tarea_recetas