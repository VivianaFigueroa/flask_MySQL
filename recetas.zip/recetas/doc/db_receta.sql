-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: localhost    Database: db_recetas
-- ------------------------------------------------------
-- Server version	8.0.31

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `db_recetas`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `db_recetas` /*!40100 DEFAULT CHARACTER SET utf8mb3 */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `db_recetas`;

--
-- Table structure for table `receta`
--

DROP TABLE IF EXISTS `receta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `receta` (
  `id` int NOT NULL AUTO_INCREMENT,
  `titulo` varchar(45) NOT NULL,
  `descripcion` varchar(255) NOT NULL,
  `instrucciones` varchar(255) NOT NULL,
  `fecha_creacion` datetime DEFAULT NULL,
  `bajo_30` tinyint NOT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `usuarios_id` int unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_receta_usuarios_idx` (`usuarios_id`),
  CONSTRAINT `fk_receta_usuarios` FOREIGN KEY (`usuarios_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `receta`
--

LOCK TABLES `receta` WRITE;
/*!40000 ALTER TABLE `receta` DISABLE KEYS */;
INSERT INTO `receta` VALUES (4,'panqueques','xzvvghthh','fdgsdfsf','2022-12-27 00:00:00',1,'2022-12-26 15:49:23','2022-12-26 15:49:23',2),(5,'queque','fgrhedsdc','dgdasffg','2022-12-28 00:00:00',1,'2022-12-26 17:25:59','2022-12-26 17:25:59',2),(6,'panqueques 2','rgdgrhbb','zgrdhtrds','2022-12-29 00:00:00',1,'2022-12-26 20:43:35','2022-12-26 20:43:35',3),(8,'cupcake','queque relleno','queque','2023-01-06 00:00:00',0,'2022-12-27 00:07:46','2022-12-27 00:07:46',2),(9,'Pizza','nsjfjsf','dhkfksfjkf','2022-12-30 00:00:00',1,'2022-12-28 20:56:05','2022-12-28 20:56:05',1);
/*!40000 ALTER TABLE `receta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuarios`
--

DROP TABLE IF EXISTS `usuarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usuarios` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(45) NOT NULL,
  `apellido` varchar(45) DEFAULT NULL,
  `email` varchar(250) NOT NULL,
  `password` varchar(100) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email_UNIQUE` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuarios`
--

LOCK TABLES `usuarios` WRITE;
/*!40000 ALTER TABLE `usuarios` DISABLE KEYS */;
INSERT INTO `usuarios` VALUES (1,'Viviana ','Figueroa','vivianafigueroag@gmail.com','$2b$12$TipGeaWbQlO.xIG8hy66x.CDobBLaUoYQOo/3HHsfl9JuqxS8Eo8m','2022-12-20 18:37:51','2022-12-20 18:37:51'),(2,'Sasha ','Figueroa','sasha@gmail.com','$2b$12$y/C73kg7R9hx8.rSRcKQZu9CXs9RKe87721ZxGh17lrwcW8ZG.oLG','2022-12-26 11:54:05','2022-12-26 11:54:05'),(3,'Tammy','Figueroa','tammy@gmail.com','$2b$12$WRqRN8Vz8PQeHwUKlvwWoOXswwv6nUsbmJE87vZ1ZelBRAATTwlsi','2022-12-26 20:42:57','2022-12-26 20:42:57'),(4,'Isabel ','Ulloa','isabel@gmail.com','$2b$12$5J3cr2Hf.DaN6pH9bPT85eG0lJ0B0SqOAkS6w8JCq6z/5k7UYW5We','2022-12-28 12:02:38','2022-12-28 12:02:38');
/*!40000 ALTER TABLE `usuarios` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Current Database: `db_examen_tv_show`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `db_examen_tv_show` /*!40100 DEFAULT CHARACTER SET utf8mb3 */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `db_examen_tv_show`;

--
-- Table structure for table `shows`
--

DROP TABLE IF EXISTS `shows`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `shows` (
  `id` int NOT NULL AUTO_INCREMENT,
  `titulo` varchar(45) NOT NULL,
  `canal` varchar(45) NOT NULL,
  `fecha_lanzamiento` datetime NOT NULL,
  `descripcion` varchar(255) NOT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `usuarios_id` int unsigned NOT NULL,
  PRIMARY KEY (`id`,`usuarios_id`),
  KEY `fk_shows_usuarios_idx` (`usuarios_id`),
  CONSTRAINT `fk_shows_usuarios` FOREIGN KEY (`usuarios_id`) REFERENCES `usuarios` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shows`
--

LOCK TABLES `shows` WRITE;
/*!40000 ALTER TABLE `shows` DISABLE KEYS */;
INSERT INTO `shows` VALUES (7,'Los Simpsons','Star +','2022-12-31 00:00:00','Especial año nuevo','2022-12-21 00:19:06','2022-12-21 00:19:06',4),(9,'Los simpsons ','canal 13','2022-12-31 00:00:00','fsdggdsdgg','2022-12-21 22:27:54','2022-12-21 22:27:54',1),(10,'pintura nueva','canal 13','2022-12-24 00:00:00','degehtrththehr','2022-12-21 22:31:24','2022-12-21 22:31:24',1),(11,'1122','star +','2022-12-23 00:00:00','dssdggsdgsd','2022-12-21 22:33:21','2022-12-21 22:33:21',9);
/*!40000 ALTER TABLE `shows` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuarios`
--

DROP TABLE IF EXISTS `usuarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usuarios` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(45) NOT NULL,
  `apellido` varchar(45) DEFAULT NULL,
  `email` varchar(250) NOT NULL,
  `password` varchar(100) NOT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email_UNIQUE` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuarios`
--

LOCK TABLES `usuarios` WRITE;
/*!40000 ALTER TABLE `usuarios` DISABLE KEYS */;
INSERT INTO `usuarios` VALUES (1,'Viviana ','Figueroa','vivianafigueroag@gmail.com','$2b$12$eSTyQkQOTBJudxreRN0xQ.Xx8LLFDXmavaeA.r0c9askdwkrAhtxu','2022-12-17 20:15:50','2022-12-17 20:15:50'),(2,'Tammy','Figueroa','tammy@gmail.com','$2b$12$RufvXn3MJulbMqKa1Z6PcOKQfX/2nM1DCH1iZZTgEjkZGr9k3Xv5q','2022-12-17 23:35:17','2022-12-17 23:35:17'),(3,'Isabel ','Ulloa','isaulloa@gmail.com','$2b$12$LEee9CGM3cyZ/yGct71BxeWDOsnDBDK3tYIJ8e1r0jrPtQHFWpSSC','2022-12-18 03:18:41','2022-12-18 03:18:41'),(4,'Blanca ','Gonzalez','blanca@gmail.com','$2b$12$QqJuCNwhr9wqUGvys3DDqegU/LIJrsGAxF9aa0Xwb07mlJDpIL5g.','2022-12-21 00:16:59','2022-12-21 00:16:59'),(5,'Alvaro','Figueroa','alvaro@gmail.com','$2b$12$PaUYYg9xekvlA.5nSu58Ce1TascIT/cxTXB0OM1IXWrt4OzrWR95m','2022-12-21 11:31:28','2022-12-21 11:31:28'),(6,'Daniela ','Figueroa','daniela@gmail.com','$2b$12$PIhIEFKPMQkqjNtIRgz2e.ixiXi1b2tmsh1uY2NI3cq5WTTIqNMC2','2022-12-21 15:42:27','2022-12-21 15:42:27'),(7,'Benito','Figueroa','benito@gmail.com','$2b$12$rK98XejOlubR415KBq8bc.visS.JcmwpgB5nlO5fwnDr6qyVVpx7W','2022-12-21 16:27:07','2022-12-21 16:27:07'),(8,'Viviana ','Gonzalez','viviana@gmail.com','$2b$12$4VnX/RPKG2rgf.X8f30XPeXIE1sLRfuShQLya3Dey0kA43f7V7WX6','2022-12-21 16:28:38','2022-12-21 16:28:38'),(9,'Alvaro','Gonzalez','alvaro1@gmail.com','$2b$12$u4uvPxQ3c5uqEUU90j.Heu/UVT.iC4dQN26I6LiLK.HqjQ0j5jUAm','2022-12-21 22:32:51','2022-12-21 22:32:51'),(10,'TOMMY','FIGUEROA','tommy@gmail.com','$2b$12$e4nL6EjtLcelGgxp1A6gtOlRZ4UvfaADo/.2eMAgM6kRr1/B7BIxW','2022-12-21 23:09:47','2022-12-21 23:09:47');
/*!40000 ALTER TABLE `usuarios` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-12-28 21:05:44
